import os, sys, tty, termios, datetime, time, shutil
import re  # Added for time validation

RESET = '\033[0m'
SELECT = '\033[7m'

apps = ["Calculator", "Notes", "FileSystem", "Clock"]
app_status = {name: False for name in apps}
selected_idx = 0
nav_mode = 0  # 0=app selection, 1=window selection
window_selected_idx = 0

app_windows = {
    "Calculator": [
        ["Add", "Subtract", "Multiply", "Divide"],
        ["Power", "Root", "Modulus", "Back"]
    ],
    "Notes": [
        ["Create", "View", "Edit", "Delete"],
        ["Search", "Export", "Import", "Back"]
    ],
    "FileSystem": [
        ["List", "Create", "Delete", "View"],
        ["Copy", "Move", "Rename", "Back"]
    ],
    "Clock": [
        ["Time", "Alarm", "Stopwatch", "Timer"],
        ["Date", "WorldClock", "Count", "Back"]
    ]
}

notes_storage = []
alarms = []
stopwatch_start = None
stopwatch_running = False
timer_end = None
timer_running = False

# ----------------- UTILITY FUNCTIONS -----------------

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def get_key():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch1 = sys.stdin.read(1)
        if ch1 == '\x1b':
            return ch1 + sys.stdin.read(2)
        return ch1
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

def pad_line(line, width):
    visible_len = len(line) - (line.count(SELECT) * len(SELECT)) - (line.count(RESET) * len(RESET))
    return line + " " * (width - visible_len)

def toggle_app(idx):
    global nav_mode
    name = apps[idx]
    if app_status[name]:
        app_status[name] = False
        nav_mode = 0
    else:
        for a in apps:
            app_status[a] = False
        app_status[name] = True

def get_selected_option(app_name):
    if not app_status[app_name]:
        return None
    if window_selected_idx < 4:
        return app_windows[app_name][0][window_selected_idx]
    else:
        return app_windows[app_name][1][window_selected_idx - 4]

def validate_time(time_str):
    """Validate HH:MM format (24-hour)"""
    return re.match(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$', time_str) is not None

# ----------------- APP FUNCTIONS -----------------

# ----- NOTES -----
def search_notes():
    if not notes_storage:
        print("No notes to search.")
        return
    search_term = input("Enter search term: ").lower()
    results = [(i, note) for i, note in enumerate(notes_storage) if search_term in note.lower()]
    if results:
        print(f"Found {len(results)} matching note(s):")
        for idx, note in results:
            print(f"{idx + 1}. {note}")
    else:
        print("No notes found.")

def export_notes():
    if not notes_storage:
        print("No notes to export.")
        return
    filename = input("Enter filename to export to: ")
    try:
        with open(filename, 'w') as f:
            for i, note in enumerate(notes_storage, 1):
                f.write(f"{i}. {note}\n")
        print(f"Notes exported to {filename}")
    except Exception as e:
        print(f"Error exporting notes: {e}")

def import_notes():
    filename = input("Enter filename to import from: ")
    try:
        with open(filename, 'r') as f:
            imported_notes = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        notes_storage.extend(imported_notes)
        print(f"Imported {len(imported_notes)} notes from {filename}")
    except Exception as e:
        print(f"Error importing notes: {e}")

# ----- FILESYSTEM -----
def copy_file():
    src = input("Enter source filename: ")
    dest = input("Enter destination filename: ")
    try:
        shutil.copy2(src, dest)
        print(f"File copied from {src} to {dest}")
    except Exception as e:
        print(f"Error copying file: {e}")

def move_file():
    src = input("Enter source filename: ")
    dest = input("Enter destination filename: ")
    try:
        shutil.move(src, dest)
        print(f"File moved from {src} to {dest}")
    except Exception as e:
        print(f"Error moving file: {e}")

def rename_file():
    old_name = input("Enter current filename: ")
    new_name = input("Enter new filename: ")
    try:
        os.rename(old_name, new_name)
        print(f"File renamed from {old_name} to {new_name}")
    except Exception as e:
        print(f"Error renaming file: {e}")

# ----- CLOCK -----
def check_alarms():
    current_time = datetime.datetime.now().strftime("%H:%M")
    triggered = [alarm for alarm in alarms if alarm == current_time]
    for alarm in triggered:
        alarms.remove(alarm)
    if triggered:
        print("ALARM!!!!")
        for alarm in triggered:
            print(f"Alarm for {alarm}!")
        print("Alarms triggered!")

def stopwatch():
    global stopwatch_start, stopwatch_running
    if not stopwatch_running:
        stopwatch_start = datetime.datetime.now()
        stopwatch_running = True
        print("Stopwatch started! Press Enter to stop...")
        input()
        stopwatch_running = False
        elapsed = datetime.datetime.now() - stopwatch_start
        print(f"Elapsed time: {elapsed}")
    else:
        elapsed = datetime.datetime.now() - stopwatch_start
        print(f"Stopwatch is running... Current time: {elapsed}")
        input("Press Enter to continue...")

def timer():
    global timer_end, timer_running
    if not timer_running:
        try:
            minutes = int(input("Enter timer duration in minutes: "))
            timer_end = datetime.datetime.now() + datetime.timedelta(minutes=minutes)
            timer_running = True
            print(f"Timer set for {minutes} minutes")
        except ValueError:
            print("Please enter a valid number")
            return
    if timer_running:
        remaining = timer_end - datetime.datetime.now()
        if remaining.total_seconds() <= 0:
            print("TIMER COMPLETE!!!")
            timer_running = False
        else:
            m, s = divmod(int(remaining.total_seconds()), 60)
            print(f"Time remaining: {m:02d}:{s:02d}")
    input("Press Enter to continue...")

def world_clock():
    print("World Clocks:")
    now = datetime.datetime.now()
    print("Local Time:", now.strftime("%Y-%m-%d %H:%M:%S"))
    print("UTC Time:", datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    print("New York:", (now - datetime.timedelta(hours=5)).strftime("%Y-%m-%d %H:%M:%S"))
    print("Tokyo:", (now + datetime.timedelta(hours=9)).strftime("%Y-%m-%d %H:%M:%S"))
    print("London:", (now + datetime.timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"))

def countdown():
    try:
        seconds = int(input("Enter countdown time in seconds: "))
        print("Starting countdown...")
        for i in range(seconds, 0, -1):
            clear()
            print(f"Countdown: {i} seconds")
            time.sleep(1)
        print("COUNTDOWN COMPLETE!!!")
    except ValueError:
        print("Please enter a valid number")
    except KeyboardInterrupt:
        print("\nCountdown cancelled")

# ----------------- RUN ACTION -----------------

def run_selected_action(app_name, option):
    clear()
    base = os.path.expanduser("~")
    if option == "Back":
        return

    check_alarms()

    if app_name == "Calculator":
        try:
            if option == "Add":
                a, b = float(input("Enter first number: ")), float(input("Enter second number: "))
                print(f"Result: {a} + {b} = {a + b}")
            elif option == "Subtract":
                a, b = float(input("Enter first number: ")), float(input("Enter second number: "))
                print(f"Result: {a} - {b} = {a - b}")
            elif option == "Multiply":
                a, b = float(input("Enter first number: ")), float(input("Enter second number: "))
                print(f"Result: {a} × {b} = {a * b}")
            elif option == "Divide":
                a, b = float(input("Enter first number: ")), float(input("Enter second number: "))
                if b == 0:
                    print("Error: Division by zero is not allowed")
                else:
                    print(f"Result: {a} ÷ {b} = {a / b}")
            elif option == "Power":
                a, b = float(input("Enter base: ")), float(input("Enter exponent: "))
                print(f"Result: {a}^{b} = {a ** b}")
            elif option == "Root":
                a = float(input("Enter number: "))
                if a < 0:
                    print("Error: Cannot calculate square root of negative number")
                else:
                    print(f"Result: √{a} = {a ** 0.5}")
            elif option == "Modulus":
                a, b = float(input("Enter first number: ")), float(input("Enter second number: "))
                if b == 0:
                    print("Error: Division by zero is not allowed")
                else:
                    print(f"Result: {a} % {b} = {a % b}")
        except ValueError:
            print("Invalid input. Please enter valid numbers.")

    elif app_name == "Notes":
        if option == "Create":
            notes_storage.append(input("Write a note: "))
            print("Note saved.")
        elif option == "View":
            if notes_storage:
                print("Your notes:")
                for i, note in enumerate(notes_storage, 1):
                    print(f"{i}. {note}")
            else:
                print("No notes saved.")
        elif option == "Edit":
            if notes_storage:
                for i, note in enumerate(notes_storage, 1):
                    print(f"{i}. {note}")
                try:
                    idx = int(input("Enter note number to edit: ")) - 1
                    if 0 <= idx < len(notes_storage):
                        notes_storage[idx] = input("Enter new text: ")
                        print("Note updated.")
                    else:
                        print("Invalid note number")
                except ValueError:
                    print("Invalid input")
            else:
                print("No notes to edit")
        elif option == "Delete":
            if notes_storage:
                for i, note in enumerate(notes_storage, 1):
                    print(f"{i}. {note}")
                try:
                    idx = int(input("Enter note number to delete: ")) - 1
                    if 0 <= idx < len(notes_storage):
                        print(f"Deleted: {notes_storage.pop(idx)}")
                    else:
                        print("Invalid note number")
                except ValueError:
                    print("Invalid input")
            else:
                print("No notes to delete")
        elif option == "Search": search_notes()
        elif option == "Export": export_notes()
        elif option == "Import": import_notes()

    elif app_name == "FileSystem":
        if option == "List":
            files = os.listdir(base)
            print(f"Files in {base}:")
            for f in files[:20]:
                print("-", f)
            if len(files) > 20:
                print(f"... and {len(files) - 20} more files")
        elif option == "Create":
            fname = input("Enter filename to create: ")
            try: 
                open(os.path.join(base, fname), 'w').close()
                print(f"Created: {fname}")
            except Exception as e: 
                print(f"Error creating file: {e}")
        elif option == "Delete":
            fname = input("Enter filename to delete: ")
            path = os.path.join(base, fname)
            if os.path.exists(path): 
                os.remove(path)
                print(f"Deleted: {fname}")
            else: 
                print("File not found")
        elif option == "View":
            fname = input("Enter filename to view: ")
            path = os.path.join(base, fname)
            if os.path.exists(path):
                try: 
                    print(f"Content of {fname}:")
                    print(open(path).read())
                except Exception as e: 
                    print(f"Error reading file: {e}")
            else: 
                print("File not found")
        elif option == "Copy": copy_file()
        elif option == "Move": move_file()
        elif option == "Rename": rename_file()

    elif app_name == "Clock":
        if option == "Time": 
            print("Current time:", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        elif option == "Alarm":
            alarm_time = input("Set alarm (HH:MM 24-hour format): ")
            if not validate_time(alarm_time):
                print("Invalid time format! Please use HH:MM (24-hour format, e.g., 14:30)")
            elif alarm_time in alarms: 
                print("Alarm already set!")
            else: 
                alarms.append(alarm_time)
                print(f"Alarm set for {alarm_time}")
        elif option == "Stopwatch": stopwatch()
        elif option == "Timer": timer()
        elif option == "Date": 
            print("Current date:", datetime.datetime.now().strftime("%A, %B %d, %Y"))
        elif option == "WorldClock": world_clock()
        elif option == "Count": countdown()

    if option != "Back": 
        input("Press Enter to return...")

# ----------------- DRAW AND LOOP -----------------

def draw():
    clear()
    print("||" + "-"*100 + "||")
    print("||MaxCore Utilities" + " "*(100-17) + "||")
    print("||" + "-"*100 + "||")
    print("||Apps              ||App Window                                                ||App Info            ||")
    print("||------------------||----------------------------------------------------------||--------------------||")
    for idx, name in enumerate(apps):
        status = "[ ]" if app_status[name] else "[x]"
        app_col = f"{status} {name}".ljust(18)
        if selected_idx == idx and nav_mode == 0: app_col = SELECT + app_col + RESET
        elif app_status[name] and nav_mode == 1: app_col = SELECT + app_col + RESET
        line1 = line2 = " " * 58
        if app_status[name]:
            line1 = "".join(SELECT + o.ljust(14) + RESET if nav_mode==1 and window_selected_idx==i else o.ljust(14) for i,o in enumerate(app_windows[name][0]))
            line2 = "".join(SELECT + o.ljust(14) + RESET if nav_mode==1 and window_selected_idx==i+4 else o.ljust(14) for i,o in enumerate(app_windows[name][1]))
            line1 = pad_line(line1, 58); line2 = pad_line(line2, 58)
        info_col = "Version 1.21.45".ljust(20)
        print(f"||{app_col}||{line1}||{info_col}||")
        print(f"||{' '*18}||{line2}||{' '*20}||")
    print("--------------------||" + " "*58 + "||" + " "*20 + "||")
    print("Version 1.0         ||" + " "*58 + "||" + " "*20 + "||")
    print("-"*104)
    if nav_mode == 0:
        print("W/S: Select App, D: Enter App Menu, X: Toggle App, Q: Quit")
    else:
        print("WASD: Navigate Menu, Enter: Execute, E: Back to App Select, Q: Quit")

# ----------------- MAIN LOOP -----------------

while True:
    draw()
    key = get_key().lower()
    
    if nav_mode == 0:
        if key == 'w':
            selected_idx = (selected_idx - 1) % len(apps)
        elif key == 's':
            selected_idx = (selected_idx + 1) % len(apps)
        elif key == 'd' or key == '\r':
            if app_status[apps[selected_idx]]:
                nav_mode = 1
                window_selected_idx = 0
        elif key == 'x':
            toggle_app(selected_idx)
        elif key == 'q':
            break
            
    else:
        if key == 'w':
            if window_selected_idx >= 4:
                window_selected_idx -= 4
            else:
                window_selected_idx += 4
        elif key == 's':
            if window_selected_idx < 4:
                window_selected_idx += 4
            else:
                window_selected_idx -= 4
        elif key == 'a':
            if window_selected_idx in [0, 4]:
                window_selected_idx += 3
            else:
                window_selected_idx -= 1
        elif key == 'd':
            if window_selected_idx in [3, 7]:
                window_selected_idx -= 3
            else:
                window_selected_idx += 1
        elif key == 'e':
            nav_mode = 0
        elif key == '\r':
            option = get_selected_option(apps[selected_idx])
            if option:
                if option == "Back":
                    nav_mode = 0
                else:
                    run_selected_action(apps[selected_idx], option)
        elif key == 'x':
            toggle_app(selected_idx)
            nav_mode = 0
        elif key == 'q':
            break